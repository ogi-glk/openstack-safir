# ========================
# Team and repository tags
# ========================
# .. image:: https://governance.openstack.org/tc/badges/openstack-ansible-os_cloudkitty.svg
#    :target: https://governance.openstack.org/tc/reference/tags/index.html
# .. Change things from this point on
OpenStack-Ansible Safir Cloud Watcher
############################
:tags: openstack, safircloudwatcher, cloud, ansible
:category: \*nix

This Ansible role installs and configures OpenStack Safir Cloud Watcher.

This role will install the following Upstart services:
    * safircloudwatcher-api
    * safircloudwatcher-processor
    * safircloudwatcher-event-manager
