from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
import os

pkg = 'safir_cloud_watcher'


def scan_sub_directories(dir_name):
    """should be recursive if there are submodules inside modules"""
    subdirs = []
    for f in os.listdir(dir_name):
        p = os.path.join(dir_name, f)
        if f is not None and os.path.isdir(p) and not f.startswith('.') and not f.startswith('__'):
            subdirs.append(p.replace(os.path.sep, '.'))
    return subdirs


def scan_directory(dir_name, files=[]):
    for f in os.listdir(dir_name):
        if f == '__init__.py':
            continue
        p = os.path.join(dir_name, f)
        if os.path.isfile(p) and p.endswith('.py'):
            if p not in["safir_cloud_watcher/api/config.py",
                        "safir_cloud_watcher/db/sqlalchemy/migrations/env.py"]:
                files.append(p.replace(os.path.sep, '.')[:-3])
        elif os.path.isdir(p):
            if p not in["safir_cloud_watcher/tests",
                        "safir_cloud_watcher/db/sqlalchemy/migrations/versions"]:
                scan_directory(p, files)
    return files


def make_extension(ext_name):
    ext_path = ext_name.replace('.', os.path.sep) + '.py'
    return Extension(
        ext_name,
        [ext_path],
        include_dirs=['.'],
    )


sub_directories = scan_sub_directories(pkg)
extNames = scan_directory(pkg)
extensions = [make_extension(name) for name in extNames]
print('\n'.join([e.sources[0] for e in extensions]))

setup(
    name=pkg,
    packages=sub_directories,
    ext_modules=cythonize(extensions,
                          compiler_directives={'language_level':"3"})
)
